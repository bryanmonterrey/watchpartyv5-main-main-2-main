const AWS = require('aws-sdk');
const medialive = new AWS.MediaLive({ region: 'us-east-1' });
const dynamodb = new AWS.DynamoDB.DocumentClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    const request = event.Records[0].cf.request;
    const streamKey = request.uri.split('/').pop();  // Extract stream key from the path

    console.log(`Received request for stream key: ${streamKey}`);

    try {
        const mediaLiveInput = await fetchMediaLiveInput(streamKey);

        if (mediaLiveInput) {
            console.log(`Found MediaLive input for stream key: ${streamKey}`);
            request.origin = {
                custom: {
                    domainName: mediaLiveInput.Destinations[0].Url.split('//')[1].split('/')[0],
                    port: 1935,
                    protocol: 'https',
                    path: '',
                    sslProtocols: ['TLSv1.2'],
                    readTimeout: 30,
                    keepaliveTimeout: 5,
                    customHeaders: {}
                }
            };
            request.uri = `/${mediaLiveInput.Destinations[0].StreamName}`;
        } else {
            console.log(`No MediaLive input found for stream key: ${streamKey}`);
            return {
                status: '404',
                statusDescription: 'Not Found',
                body: 'Stream not found'
            };
        }
    } catch (error) {
        console.error('Error processing request:', error);
        return {
            status: '500',
            statusDescription: 'Internal Server Error',
            body: 'Error processing request'
        };
    }

    return request;
};

async function fetchMediaLiveInput(streamKey) {
    // First, try to fetch from DynamoDB
    const params = {
        TableName: 'StreamKeys',
        Key: { streamKey: streamKey }
    };

    try {
        const result = await dynamodb.get(params).promise();
        if (result.Item) {
            return result.Item.mediaLiveInput;
        }
    } catch (error) {
        console.error('Error fetching from DynamoDB:', error);
    }

    // If not found in DynamoDB, fetch from MediaLive
    const inputs = await medialive.listInputs().promise();
    const input = inputs.Inputs.find(input => input.Name.includes(streamKey));

    if (input) {
        // Store in DynamoDB for future quick lookups
        await dynamodb.put({
            TableName: 'StreamKeys',
            Item: {
                streamKey: streamKey,
                mediaLiveInput: input
            }
        }).promise();
    }

    return input;
}