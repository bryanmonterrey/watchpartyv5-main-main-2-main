exports.handler = async (event) => {
    console.log('Event received:', JSON.stringify(event, null, 2));
    const request = event.Records[0].cf.request;
    console.log('Original request:', JSON.stringify(request, null, 2));
    
    const streamKey = request.uri.split('/').pop();
    console.log(`Received request for stream key: ${streamKey}`);

    try {
        // Hardcode the MediaLive input details for now
        const mediaLiveInput = {
            Destinations: [
                {
                    Url: 'rtmp://54.90.10.243:1935/980dc3d6-1382-4125-97dc-e18e0f0c66ec-c57b82cecd37406a'
                }
            ]
        };
        
        console.log('MediaLive input:', JSON.stringify(mediaLiveInput, null, 2));

        if (mediaLiveInput) {
            console.log(`Found MediaLive input for stream key: ${streamKey}`);
            request.origin = {
                custom: {
                    domainName: mediaLiveInput.Destinations[0].Url.split('//')[1].split('/')[0],
                    port: 1935,
                    protocol: 'rtmp',
                    path: '',
                    sslProtocols: ['TLSv1.2'],
                    readTimeout: 30,
                    keepaliveTimeout: 5,
                    customHeaders: {}
                }
            };
            request.uri = `/${mediaLiveInput.Destinations[0].Url.split('/').pop()}`;
            console.log('Updated request:', JSON.stringify(request, null, 2));
        } else {
            console.log(`No MediaLive input found for stream key: ${streamKey}`);
            return {
                status: '404',
                statusDescription: 'Not Found',
                body: 'Stream not found'
            };
        }
    } catch (error) {
        console.error('Error processing request:', error);
        return {
            status: '500',
            statusDescription: 'Internal Server Error',
            body: 'Error processing request'
        };
    }

    return request;
};